package com.kodego.diangca.ebrahim.myslambook.model

class Hobbies(var hobbie:String = "") {
}