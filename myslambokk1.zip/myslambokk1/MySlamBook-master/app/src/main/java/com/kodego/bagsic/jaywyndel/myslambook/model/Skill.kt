package com.kodego.diangca.ebrahim.myslambook.model

class Skill(var skill:String = "", var rate:Int = 0) {
}