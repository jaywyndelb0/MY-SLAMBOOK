package com.kodego.diangca.ebrahim.myslambook.model

class Movie(var movieName:String = "") {
}