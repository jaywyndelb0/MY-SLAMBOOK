package com.kodego.diangca.ebrahim.myslambook.model

class Song(var songName:String = "") {
}